#!/usr/local/bin/node
var fs = require('fs');
var util = require('util');
// Default config values
var rc = require('rc')('fh-amqp-js', {
  maxReconnectAttempts: 10
});
var fhamqpjs = require('./lib/amqpjs.js');

function usage() {
  console.log("Usage: fh-amqp-js pub <exchange> <topic> <message> --clusterNodes=[<amqp-url>,*]\n"
                   + "fh-amqp-js sub <exchange> <topic> --clusterNodes=[<amqp-url>,*]\n");
  process.exit(1);
};

var cmd = rc._[0];
if (!cmd) usage();
if (cmd !== 'pub' && cmd !== 'sub') usage();

if (cmd === 'pub') {
  if (rc._.length !== 4) usage();

  var amqpManager = new fhamqpjs.AMQPManager(rc);
  amqpManager.on("error", function(err){
    fatal(err);
  });

  amqpManager.connectToCluster();

  amqpManager.on("connection", function(){
    amqpManager.publishTopic(rc._[1], rc._[2], JSON.parse(rc._[3]), function(err){
      if(err) fatal(err);
      amqpManager.disconnect();
    });
  });
}

if (cmd === 'sub') {
  if (rc._.length < 2) usage();

  var amqpManager = new fhamqpjs.AMQPManager(rc);
  amqpManager.on("error", function(err){
    fatal(err);
  });

  amqpManager.connectToCluster();

  amqpManager.on("connection", function(){
    var opts = {
      autoDelete: true,
      durable: false
    };
    var q = "fh-amqp-js-cli-" + new Date().getTime();
    amqpManager.subscribeToTopic(rc._[1], q, rc._[2], subscribeFunc, opts, function(err){
      if(err) fatal(err);
    });
  });

  function subscribeFunc (json, headers, deliveryInfo) {
    console.log(json);
  };

}

function fatal(msg) {
  console.error(msg);
  process.exit(1);
};